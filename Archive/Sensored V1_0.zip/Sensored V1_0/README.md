# Sensored - Embedded
There is CURRENTLY NO DOCUMENTATION in this section yet as I have not verified the circuit board and have not tested it yet.

![Embedded_Capabilities](/.assets/Undaconstwuction.png)